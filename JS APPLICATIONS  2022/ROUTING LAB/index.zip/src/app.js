
import {page, render} from  './lib.js'
import { getUserData } from './util.js';
import {catalogPage} from  './views/catalog.js'
import { createPage } from './views/create.js';
import { detailsPage } from './views/details.js';
import { editPage } from './views/edit.js';
import { loginPage } from './views/login.js';
import { registerPage } from './views/register.js';

const root = document.getElementsByTagName('main')[0];

page(decorateContext);
page('/', catalogPage);
page('/home', catalogPage);
page('/create', createPage);
page('/details/:id', detailsPage);
page('/edit', editPage);
page('/login', loginPage);
page('/register', registerPage);

updateNav();
page.start();
   

function decorateContext (ctx, next) {
    ctx.render = (template) => render(template, root);
    ctx.updateNav = updateNav;    
    next();
}


function updateNav(){
const userData = getUserData();
if(userData){
    [...document.querySelectorAll('nav .user')].forEach(n => n.style.display = 'inline-block');
    [...document.querySelectorAll('nav .guest')].forEach(n => n.style.display = 'none');

    document.getElementById('welcome-msg').textContent = `Welcome, ${userData.email}`;
}
else{
    [...document.querySelectorAll('nav .user')].forEach(n => n.style.display = 'none');
    [...document.querySelectorAll('nav .guest')].forEach(n => n.style.display = 'block');
}

};



