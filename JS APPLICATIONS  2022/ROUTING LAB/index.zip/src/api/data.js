import * as api from './api.js'


    export const login = await api.login;
    export const register = await api.register;
    export const logout = await api.logout;

    const endpoints ={
        allMovies: '/data/movies',
        movieById : '/data/movies/'
    }


    export async function getAllMOvies () {

        return api.get(endpoints.allMovies);
    }

    export async function getMovieById (id){

        return api.get(endpoints.movieById + id);
    }