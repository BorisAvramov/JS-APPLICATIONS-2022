import { loadAllFurnitures } from "../api/data.js";
import { until, html     } from "../lib.js";


const catalogTemplate = (loadFurPromise) => html`<div class="container">
<div class="row space-top">
    <div class="col-md-12">
        <h1>Welcome to Furniture System</h1>
        <p>Select furniture from the catalog to view details.</p>
    </div>
</div>
<div class="row space-top">
    ${until(loadFurPromise, html`<p>Loading &hellip;</p>`)}
    
</div>
</div>`;

const furnitureCardTEmplate = (furniture) => html`
    <div class="col-md-4">
        <div class="card text-white bg-primary">
            <div class="card-body">
                    <img src=${furniture.img} />
                    <p>Description here</p>
                    <footer>
                        <p>Price: <span>${furniture.price} $</span></p>
                    </footer> 
                    <div>
                        <a href=${`/details/${furniture._id}`} class="btn btn-info">Details</a>
                    </div>
            </div>
        </div>
    </div>`;



export function showCatalog (ctx){

    ctx.render(catalogTemplate(loadFurnitures()));

}


async function loadFurnitures () {

    const furnitures = await loadAllFurnitures();

    return furnitures.map(f => furnitureCardTEmplate(f));

}