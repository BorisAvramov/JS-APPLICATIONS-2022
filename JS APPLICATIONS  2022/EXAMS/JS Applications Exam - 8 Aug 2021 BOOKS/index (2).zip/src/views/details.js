import {html, page} from '../lib.js'
import {deleteBook, loadBookById} from '../api/data.js'
import { getUserData } from '../util.js'

const DetailsTempl = (book, onDel) => html`<section id="details-page" class="details">
<div class="book-information">
    <h3>${book.title}</h3>
    <p class="type">Type: ${book.type}</p>
    <p class="img"><img src=${book.imageUrl}></p>
    <div class="actions">
        ${book.isOwner
        ? html `  <a class="button" href="/edit/${book._id}">Edit</a>
        <a class="button" href="#" @click=${onDel}>Delete</a>` 
        : html ` `}
         ${book.isUser && !book.isOwner
        ? html `<a class="button" href="#">Like</a>`
        : html ``}
        ${html `<div class="likes">
            <img class="hearts" src="/images/heart.png">
            <span id="total-likes">Likes: 0</span>
        </div>`}
        
        
        
       
      


    </div>
</div>
<div class="book-description">
    <h3>Description:</h3>
    <p>${book.description}</p>
</div>
</section>`




export async function showDetails(ctx){
    console.log(ctx);
    const book = await loadBookById(ctx.params.id);

    const userData = getUserData();
    if(userData){
        book.isUser = true;
    }
    if(userData && book._ownerId == userData.id){
        book.isOwner = true;
    }
    ctx.render (DetailsTempl(book, onDel));

    async function onDel(e){
        e.preventDefault();

        await deleteBook(book._id);
        page.redirect('/catalog');


    }
    

}